\##Teppotomppa's translator mod

Testing on how to translate the game from Englinsh to Finnish. Still in development phase :D
