##Teppotomppa's translator mod

This is a test on how to translate the entire game from English to Finnish. Nothing to see here.